package com.rocketseat.certification_nlw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertificationNlwApplicationTests {

	@Test
	void contextLoads() {
	}

}
